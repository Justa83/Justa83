dbt-cli
=======

This codebase is used to publish new binary versions of the dbt Cloud CLI.

For more information visit the [docs](https://docs.getdbt.com/docs/cloud/cloud-cli-installation).